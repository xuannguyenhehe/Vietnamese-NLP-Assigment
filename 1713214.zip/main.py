# main.py
# -------------
from viNLP import ViNLP
import optparse
import os
import sys

def database(line):
    col = line.split(";")
    typ = col[0]
    name = col[1]
    place = col[2]
    time = col[3]
    return typ, name, place, time

# register arguments and set default values
def readCommand(argv):
    parser = optparse.OptionParser(
        description='Run public tests on student code')
    parser.add_option('--model-directory',
                      dest='modelRoot',
                      default='models',
                      help='Root model directory which contains models')
    parser.add_option('--test-directory',
                      dest='testRoot',
                      default='inputs',
                      help='Root test directory which contains inputs')
    parser.add_option('--model',
                      dest='modelFilename',
                      default='model01.txt',
                      help='File name which contains the model')                  
    parser.add_option('--input',
                      dest='testFilename',
                      default="input01.txt",
                      help='File name which contains the input')
    parser.add_option('--database',
                      dest="databaseFilename",
                      default='database.txt',
                      help='File name which contains the database')
    parser.add_option('--output',
                      dest="outputFilename",
                      default='output01.txt',
                      help='File name which contains the output')
    (options, _) = parser.parse_args(argv)
    return options

if __name__ == '__main__':
    options = readCommand(sys.argv)
    model = ViNLP(options.modelRoot + '/' + options.modelFilename)
    lstDependency = model.DependencyGrammar(options.testRoot + '/' + options.testFilename)
    mod = model.flattenDependencyGrammar(lstDependency)
    print(mod)

    pattern = model.PatternForm(lstDependency)
    relation = model.Relation(pattern)
    result_a = model.flattenRelation(relation)
    print(result_a)

    logical= model.Logical(relation)
    result_b = model.flattenLogical(logical)
    print(result_b)

    query = model.Query(logical)
    result_c = model.flattenQuery(query)
    print(result_c)    

    f = open(options.databaseFilename, 'r', encoding='utf8')
    lines = f.readlines()
    db = []
    for line in lines:
        typ, name, place, time = database(line)
        db.append([typ, name, place, time])

    resultdb = model.resultDB(db, query)
    result_d = model.flattenResultDB(resultdb)
    print(result_d)

    f = open('./outputs/' + options.outputFilename, 'w', encoding='utf8')
    writeline = mod + '\n' + result_a + '\n' + result_b + '\n' + result_c + '\n' + result_d
    f.write(writeline)
    f.close()
   