import numpy as np
import re

def getCityName(name):
    if name == "HUẾ":
        return "HUE"
    if name == "HỒ":
        return "HCMC"
    if name == "ĐÀ":
        return "DANANG"

def dependencyGrammar(listWord, listTag):
    listLabel = {}
    for index in range(len(listWord)):
        if listTag[listWord[index]].typTag == "V":
            verb = listWord[index]
            indexVerb = index
            break
    listLabel[verb] = Label(indexVerb, verb, np.array([indexVerb, -1]), "Root")
    det = []
    for index in range(len(listWord)):
        if listTag[listWord[index]].typTag == "DET":
            det.append(listWord[index])
    if len(det) == 1:
        indexDet = listWord.index(det[0])  
        if indexDet == 0:
            listLabel[det[0]] = Label(indexDet, det[0], np.array([indexDet, indexVerb]), "det_wh")
        else:
            noun = listWord[indexDet - 1]
            if listTag[noun].typTag == "N":
                listLabel[det[0]] = Label(indexDet, det[0], np.array([indexDet, indexDet - 1]), "det_wh")
    else:
        indexDetFirst = listWord.index(det[0]) 
        indexDetSecond = listWord.index(det[1]) 
        listLabel[det[0]] = Label(indexDetFirst, det[0], np.array([indexDetFirst, indexDetFirst + 1]), "det")
        listLabel[det[1]] = Label(indexDetSecond, det[1], np.array([indexDetSecond, indexDetFirst - 1]), "det_wh")
    subj = [word for word in listWord[:indexVerb + 1] if listTag[word].typTag == "N"][-1]
    indexSubj = listWord.index(subj)  
    listLabel[subj] = Label(indexSubj, subj, np.array([indexSubj, indexVerb]), "nsubj")
    obj = [word for word in listWord[indexVerb:] if listTag[word].typTag == "PRO"][-1]
    indexObj = listWord.index(obj)  
    listLabel[obj] = Label(indexObj, obj, np.array([indexObj, indexVerb]), "nobj")
    pobj = [word for word in listWord[indexVerb:] if listTag[word].typTag == "PRO_TIME"]
    if pobj:
        indexPobj = listWord.index(pobj[0])  
        listLabel[pobj[0]] = Label(indexPobj, pobj[0], np.array([indexPobj, indexVerb]), "pobj")
    for index in range(len(listWord)):
        pro = listWord[index]
        if listTag[pro].typTag == "PRO":
            if listTag[listWord[index - 1]].typTag == "N":
                nmod = listWord[index - 1]
                indexNmod = listWord.index(nmod)  
                listLabel[nmod] = Label(indexNmod, nmod, np.array([indexNmod, index]), "nmod")
    for index in range(len(listWord)):
        pro_time = listWord[index]
        if listTag[pro_time].typTag == "PRO_TIME":
            if listTag[listWord[index - 1]].typTag == "P":
                pmod = listWord[index - 1]
                indexPmod = listWord.index(pmod)  
                listLabel[pmod] = Label(indexPmod, pmod, np.array([indexPmod, index]), "pmod")
    return listLabel

class Condition:
    def __init__(self, typCon, varCon, placeCon, timeCon):
        self.typCon = typCon
        self.varCon = varCon
        self.placeCon = placeCon
        self.timeCon = timeCon

class Query:
    def __init__(self, key, variable, listCondition):
        self.key = key
        self.variable = variable
        self.listCondition = listCondition

class Logical:
    def __init__(self, relation, variable, descendant):
        self.relation = relation
        self.variable = variable
        self.descendant = descendant

class Relation:
    def __init__(self, role, first, second):
        self.role = role
        self.first = first
        self.second = second

class Pattern:
    def __init__(self, left, relation, right):
        self.left = left
        self.relation = relation
        self.right = right

class Label:
    def __init__(self, index, name, arrow, relation):
        self.index = index
        self.name = name
        self.arrow = arrow
        self.relation = relation

class Arc:
    def __init__(self, arc, arrowhead, arrowtail):
        self.arc = arc
        self.arrowhead = arrowhead
        self.arrowtail = arrowtail

class Tag:
    def __init__(self, nameTag, typTag):
        self.nameTag = nameTag
        self.typTag = typTag

class ViNLP:
    def __init__(self, filename):
        listTag = {}
        f = open(filename, 'r', encoding="utf8")
        lines = f.readlines()
        for line in lines:
            nameTag, typTag = self.__extract_model(line)
            listTag[nameTag] = Tag(nameTag, typTag)
        f.close()
        self.listTag = listTag
    
    def DependencyGrammar(self, filename):
        f = open(filename, 'r', encoding="utf8")
        input = self.__extract_query(f.readline())
        listTag = [tag for tag in self.listTag]
        dependency = dependencyGrammar(listTag, self.listTag)
        listDependency = {}
        for element in dependency:
            relation = dependency[element].relation
            index = dependency[element].arrow[1]
            if index != -1:
                for dep in dependency:
                    if dependency[dep].index == index:
                        arrowhead = dep
                listDependency[relation] = Arc(relation, arrowhead, element)
            else:
                continue
        return listDependency
    
    def flattenDependencyGrammar(self, listDependency):
        result = ""
        for dep in listDependency:
            result += listDependency[dep].arc + '(' + listDependency[dep].arrowhead + ',' + listDependency[dep].arrowtail + ')\n'
        return result

    def PatternForm(self, listDependency):
        listPattern = []
        for dep in listDependency:
            if dep == "det_wh":
                listPattern.append(Pattern('s1', 'WH-Q', None))
            if dep == "nsubj":
                listPattern.append(Pattern('s1', 'PRED', listDependency[dep].arrowhead))
                listPattern.append(Pattern('s1', 'TNS', 'PRES'))
                listPattern.append(Pattern('s1', 'LSUBJ', listDependency[dep].arrowtail.upper()))
            if re.search("^.obj$", dep):
                name = 'NAME ' + listDependency[dep].arrowtail[0] + '1 ' + listDependency[dep].arrowtail.upper()
                listPattern.append(Pattern('s1', 'LOBJ', name))
        return listPattern

    def Relation(self, relationGrammar):
        listRelationGrammar = []
        for pat in relationGrammar:
            relation = pat.relation
            left = pat.left
            right = pat.right
            if relation == "WH-Q":
                listRelationGrammar.append(Relation("WH-QUERY", left, None))
            if relation == "PRED" or relation == "TNS":
                if relation == "PRED":
                    verb = right.upper()
                listRelationGrammar.append(Relation(right.upper(), left, None))
            if relation == "LSUBJ":
                listRelationGrammar.append(Relation("AGENT", left, right))
            if relation == "LOBJ":
                name = right.split(' ')
                if re.search("^[0-9]{2}[:][0-9]{2}HR$", name[2]):
                    listRelationGrammar.append(Relation("AT-TIME", left, right))
                else:
                    if verb == "XUẤT PHÁT":
                        listRelationGrammar.append(Relation("FROM-LOC", left, right))
                    else:
                        listRelationGrammar.append(Relation("TO-LOC", left, right))
        return listRelationGrammar

    def flattenRelation(self, relation):
        result = ""
        for rel in relation:
            value = ' (' + rel.second + ')' if rel.second else ''
            result += '(' + rel.role + ' ' + rel.first + value + ')\n'
        return result

    def Logical(self, relation):
        listLogical = []
        variable = relation[0].first
        descendant = []
        relate = ""
        for rel in relation:
            if rel.role == "WH-QUERY":
                relate += rel.role
                continue
            elif rel.role not in ["PRES", "AGENT", "FROM-LOC" ,"TO-LOC", "AT-TIME", "WH-QUERY"]:
                relate += '(' + rel.role + ' ' + rel.first + ' '
                continue
            elif rel.role == "PRES":
                relate += rel.role + ')'
                continue
            else:
                descendant.append(rel)
        listLogical.append(Logical(relate, variable, descendant))
        return listLogical

    def flattenLogical(self, listLogical):
        result = ''
        for logi in listLogical:
            descendant = ''
            for ele in logi.descendant:
                descendant += '[' + ele.role + ' ' + ele.first + ' ' + ele.second + ']'
            result += '(' + logi.relation + ' ' + logi.variable + ' ' + descendant + ')'
        return result

    def Query(self, listLogical):
        if len(listLogical) == 1:
            first = listLogical[0]
            role = first.relation
            listQuery = []
            key = "PRINT-ALL"
            variable = '?b'
            listQuery.append(Condition("BUS", variable, None, None))
            if re.findall("ĐẾN", role):
                for child in first.descendant:
                    if child.role == "TO-LOC":
                        listQuery.append(Condition("ATIME", variable, child.second, None))
                    if child.role == "AT-TIME":
                        listQuery.append(Condition("ATIME", variable, None, child.second))
            if re.findall("XUẤT PHÁT", role):
                for child in first.descendant:
                    if child.role == "FROM-LOC":
                        listQuery.append(Condition("DTIME", variable, child.second, None))
                    if child.role == "AT-TIME":
                        listQuery.append(Condition("DTIME", variable, None, child.second))
        return Query(key, variable, listQuery)

    def flattenQuery(self, query):
        listCondition = ""
        key = query.key
        variable = query.variable
        for re in query.listCondition:
            typCon = re.typCon
            varCon = re.varCon
            placeCon = re.placeCon
            timeCon = re.timeCon
            if typCon == "BUS":
                listCondition += '(' + typCon + ' ' + varCon + ')'
            elif placeCon and timeCon:
                listCondition += '(' + typCon + ' ' + varCon + ' ' + '(' + placeCon + ')' + ' ' +  '(' + timeCon + '))'
            elif placeCon:
                listCondition += '(' + typCon + ' ' + varCon + ' ' + '(' + placeCon + ')' +')'
            elif timeCon:
                listCondition += '(' + typCon + ' ' + varCon + ' ' + '(' + timeCon + ')' +')'
        return '(' + key + ' ' + variable + ' ' + listCondition + ')'

    def resultDB(self, db, retrieveForm):
        lstResult = []
        if retrieveForm.variable == "?b":
            myquery = []
            for fu in retrieveForm.listCondition[1:]:
                typ = fu.typCon
                place = fu.placeCon
                time = fu.timeCon
                place = place.split(' ')[2] if place else None
                time = time.split(' ')[2] if time else None
                if place and time:
                    for index in range(len(db)):
                        if db[index][0] == typ and db[index][2] == getCityName(place) and db[index][3] == time:
                            myquery.append(db[index])
                elif place:
                    for index in range(len(db)):
                        if db[index][0] == typ and db[index][2] == getCityName(place):
                            myquery.append(db[index])
                elif time:
                    for index in range(len(db)):
                        if db[index][0] == typ and db[index][3] == time:
                            myquery.append(db[index])
                db = myquery
                myquery = []
            for x in db:
                lstResult.append(x[1])
        return lstResult

    def flattenResultDB(self, resultdb):
        if len(resultdb) == 0:
            return 'Không tìm được dữ liệu'
        else:
            result = ""
            for re in resultdb:
                result += re + ' '
            return result

    def __extract_model(self, line):
        parts = line.split(';')
        name = parts[0]
        typ = parts[1]
        return name, typ

    def __extract_query(self, line):
        words = line.split(' ')
        return words